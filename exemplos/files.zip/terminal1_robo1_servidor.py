"""
TERMINAL 1 — roda PRIMEIRO, nos outros dois.
Precisa de: pip install pygame

Esse processo faz 2 coisas:
  1. Controla o robô 1 (controle do pygame -> EV3 pela Bluetooth)
  2. Hospeda a página web (cronômetro + rankings) na porta 8765

Os terminais 2 e 3 (robo2.py / robo3.py) mandam o estado deles pra
esse servidor via HTTP (POST /estado/<nome>). Por isso esse aqui
tem que estar de pé antes de rodar os outros dois.

Antes de rodar: conecta SÓ o controle do robô 1 (os outros 2 ficam
pra conectar nos terminais 2 e 3). Se já tiver mais de um conectado,
passa o índice: python terminal1_robo1_servidor.py 0

ESC ou fecha a janela do pygame = para o robô 1 e derruba o servidor.
"""
import json
import os
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

os.environ['SDL_JOYSTICK_HIDAPI'] = '0'

import pygame
from jacarev3 import RoboEV3, protocolo as p

NOME_ROBO = 'robo1-vermelho'
MAC_ROBO = '00:16:53:64:D9:69'
COR_IDENTIDADE = 'VERMELHO'  # cor fixa do LED enquanto esse robô roda

MOTOR_ESQ = 'C'
MOTOR_DIR = 'B'
SINAL_ESQ = -1
SINAL_DIR = -1

PORTA_GATILHO = 4
CODIGO_COR_GATILHO = 5  # 5 = vermelho

EIXO_RT = 4
EIXO_LT = 5
EIXO_DIRECAO = 0

# Mapeamento por marca de controle — cada marca/driver reporta os
# eixos de analógico e gatilho em índices diferentes. Detecta pelo
# nome do dispositivo e troca só os números, sem mexer no padrão
# Xbox de cima. Roda testar_controle.py com o PS4 pra descobrir os
# índices certos (mexe no analógico esquerdo e no R2/L2, vê qual
# número muda) e preenche abaixo — os valores de PS4 aqui embaixo
# são só um ponto de partida, PRECISA confirmar no seu driver/SO.
MAPEAMENTOS_CONHECIDOS = [
    (['xbox', '360', 'xinput'], {'rt': EIXO_RT, 'lt': EIXO_LT, 'direcao': EIXO_DIRECAO}),
    (['wireless controller', 'ps4', 'dualshock', 'sony'], {'rt': 4, 'lt': 3, 'direcao': 0}),  # <- confirmar
]
MAPEAMENTO_PADRAO = {'rt': EIXO_RT, 'lt': EIXO_LT, 'direcao': EIXO_DIRECAO}


def escolher_mapeamento(nome_controle):
    nome = nome_controle.lower()
    for chaves, mapa in MAPEAMENTOS_CONHECIDOS:
        if any(chave in nome for chave in chaves):
            return mapa
    print(f"Controle '{nome_controle}' não tá na lista de mapeamentos — usando padrão Xbox.")
    return MAPEAMENTO_PADRAO

VEL_MAX = 60
GANHO_VIRA = 35
ACELERACAO_POR_S = 50
FREADA_POR_S = 90
RAMPA_MOTOR = 14

ZONA_MORTA_STICK = 0.15
ZONA_MORTA_GATILHO = 0.05
TAXA_LOOP_S = 0.05

PORTA_SERVIDOR = 8765


def limitar(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def aproximar(atual, alvo, passo_max):
    diff = alvo - atual
    if diff > passo_max:
        diff = passo_max
    elif diff < -passo_max:
        diff = -passo_max
    return atual + diff


def aplicar_zona_morta(v, zona):
    if -zona < v < zona:
        return 0.0
    sinal = -1.0 if v < 0 else 1.0
    return sinal * (abs(v) - zona) / (1 - zona)


def gatilho_para_0_1(valor_eixo, repouso):
    escala = 1 - repouso
    if escala <= 0:
        return 0.0
    v = (valor_eixo - repouso) / escala
    v = max(0.0, v)
    return v if v > ZONA_MORTA_GATILHO else 0.0


def ligar_led_identidade(robo):
    # LED fica sempre na cor do robô — largada/chegada agora avisam
    # por apito (frequência já é diferente pra cada um), não trocando
    # a cor, senão perde a identidade visual no meio da corrida.
    try:
        robo.led(COR_IDENTIDADE)
    except Exception as e:
        print(f"Aviso: cor de LED '{COR_IDENTIDADE}' não existe nesse firmware ({e}) — usando verde.")
        robo.led('VERDE')


def piscar_identidade(robo, vezes=1, atraso=0.15):
    for _ in range(vezes):
        robo.led('DESLIGADO')
        time.sleep(atraso)
        ligar_led_identidade(robo)
        time.sleep(atraso)


# ===================================================================
# Estado compartilhado — robô 1 (local) + robos 2/3 (recebidos por HTTP)
# ===================================================================
lock_estado = threading.Lock()
estado_robo1 = {'rodando': False, 'largada': None, 'ultimo_tempo': None, 'id_finalizacao': 0}
estados_externos = {}  # nome -> dict já pronto, mandado pelos outros terminais


def largar_robo1():
    with lock_estado:
        estado_robo1['rodando'] = True
        estado_robo1['largada'] = time.perf_counter()


def chegar_robo1():
    with lock_estado:
        tempo = time.perf_counter() - estado_robo1['largada']
        estado_robo1['rodando'] = False
        estado_robo1['ultimo_tempo'] = tempo
        estado_robo1['id_finalizacao'] += 1
        return tempo


def esta_rodando_robo1():
    with lock_estado:
        return estado_robo1['rodando']


def estado_completo_json():
    with lock_estado:
        tempo_atual = (
            time.perf_counter() - estado_robo1['largada']
            if estado_robo1['rodando'] and estado_robo1['largada'] else 0.0
        )
        saida = {
            NOME_ROBO: {
                'rodando': estado_robo1['rodando'],
                'tempo': tempo_atual,
                'ultimo_tempo': estado_robo1['ultimo_tempo'],
                'id_finalizacao': estado_robo1['id_finalizacao'],
            }
        }
        saida.update(estados_externos)
        return json.dumps(saida)


# ===================================================================
# Página — cronômetro de cada robô + 2 rankings (igual pros 3)
# ===================================================================
PAGINA_HTML = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Corrida Multi EV3</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700;9..144,900&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #efe9da;
    --tinta: #1a1812;
    --tinta-fraca: #6b6558;
    --linha: #1a1812;
    --vermelho: #bf3b26;
    --verde: #2f6e3a;
    --ouro: #b8860b;
    --placa: #fbf8f0;
    --azul: #2f5d8a;
    --verde-robo: #2f8a4f;
    --amarelo-robo: #c9972b;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    background: var(--bg);
    color: var(--tinta);
    font-family: Georgia, "Times New Roman", serif;
    padding: 0 0 64px;
  }
  .faixa {
    height: 14px;
    background-image: repeating-linear-gradient(90deg, var(--tinta) 0 22px, transparent 22px 44px);
    background-color: var(--bg);
  }
  .topo {
    max-width: 920px;
    margin: 0 auto;
    padding: 36px 20px 28px;
  }
  .rotulo-evento {
    font-family: "Space Mono", monospace;
    font-size: 13px;
    letter-spacing: 0.02em;
    color: var(--vermelho);
    margin: 0 0 10px;
  }
  h1 {
    font-family: "Fraunces", Georgia, serif;
    font-weight: 900;
    font-optical-sizing: auto;
    font-size: clamp(38px, 8vw, 68px);
    line-height: 0.98;
    margin: 0 0 12px;
    max-width: 14ch;
  }
  .subtitulo {
    font-size: 17px;
    color: var(--tinta-fraca);
    max-width: 46ch;
    line-height: 1.5;
    margin: 0;
  }
  .envolto { max-width: 920px; margin: 0 auto; padding: 0 20px; }
  section { margin-top: 40px; }
  .titulo-secao {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    border-bottom: 3px solid var(--linha);
    padding-bottom: 10px;
    margin-bottom: 0;
  }
  .titulo-secao h2 {
    font-family: "Fraunces", Georgia, serif;
    font-weight: 700;
    font-size: 24px;
    margin: 0;
  }
  .titulo-secao .contagem {
    font-family: "Space Mono", monospace;
    font-size: 13px;
    color: var(--tinta-fraca);
  }
  .pista {
    display: flex;
    align-items: center;
    gap: 18px;
    padding: 18px 4px;
    border-bottom: 1px solid var(--linha);
  }
  .pista:first-of-type { border-top: 1px solid var(--linha); }
  .pista .robo-nome {
    font-family: "Space Mono", monospace;
    font-size: 13px;
    color: var(--tinta-fraca);
    width: 92px;
    flex-shrink: 0;
    text-transform: uppercase;
  }
  .ponto-cor {
    display: inline-block;
    width: 9px;
    height: 9px;
    margin-right: 6px;
    vertical-align: middle;
  }
  .cor-vermelho { background: var(--vermelho); }
  .cor-verde { background: var(--verde-robo); }
  .cor-amarelo { background: var(--amarelo-robo); }
  .pista .numero {
    font-family: "Space Mono", monospace;
    font-size: clamp(26px, 5vw, 40px);
    font-weight: 700;
    flex-shrink: 0;
    min-width: 7ch;
  }
  .pista .rotulo {
    font-size: 13px;
    color: var(--tinta-fraca);
    width: 84px;
    flex-shrink: 0;
  }
  .pista .rotulo.correndo { color: var(--verde); }
  .pista .rotulo.chegou { color: var(--vermelho); }
  .pista form {
    display: flex;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }
  .pista input {
    flex: 1;
    min-width: 0;
    font-family: Georgia, serif;
    font-size: 14px;
    border: none;
    border-bottom: 2px solid var(--linha);
    background: transparent;
    color: var(--tinta);
    padding: 6px 2px;
  }
  .pista input:focus { outline: none; border-bottom-color: var(--vermelho); }
  .pista button {
    font-family: "Space Mono", monospace;
    font-size: 13px;
    border: 2px solid var(--linha);
    background: var(--tinta);
    color: var(--placa);
    padding: 8px 16px;
    cursor: pointer;
    font-weight: bold;
  }
  .pista button:active { background: var(--vermelho); border-color: var(--vermelho); }
  .placar { border-top: 1px solid var(--linha); }
  .linha-resultado {
    display: grid;
    grid-template-columns: 44px 1fr auto;
    gap: 14px;
    align-items: baseline;
    padding: 12px 4px;
    border-bottom: 1px solid var(--linha);
  }
  .linha-resultado .posicao {
    font-family: "Space Mono", monospace;
    font-weight: 700;
    font-size: 15px;
  }
  .linha-resultado .quem { font-size: 15px; }
  .linha-resultado .quem .robo {
    font-family: "Space Mono", monospace;
    font-size: 12px;
    color: var(--tinta-fraca);
    text-transform: uppercase;
    margin-right: 8px;
  }
  .linha-resultado .tempo {
    font-family: "Space Mono", monospace;
    font-size: 15px;
    font-weight: 700;
  }
  .linha-resultado.primeiro {
    background: var(--tinta);
    color: var(--placa);
    margin: 0 -10px;
    padding: 14px 14px;
    border-bottom-color: var(--tinta);
  }
  .linha-resultado.primeiro .quem .robo { color: #c9c3b2; }
  .linha-resultado.primeiro .tempo,
  .linha-resultado.primeiro .posicao { color: var(--ouro); }
  .vazio {
    color: var(--tinta-fraca);
    font-size: 14px;
    padding: 24px 4px;
    text-align: center;
    border-bottom: 1px solid var(--linha);
  }
  .rodape-secao { display: flex; justify-content: flex-end; margin-top: 14px; }
  button.secundario {
    font-family: "Space Mono", monospace;
    font-size: 12px;
    letter-spacing: 0.02em;
    border: none;
    background: none;
    color: var(--tinta-fraca);
    text-decoration: underline;
    padding: 4px 0;
    cursor: pointer;
  }
  button.secundario:active { color: var(--vermelho); }
  @media (max-width: 520px) {
    .pista { flex-wrap: wrap; }
    .pista .robo-nome { width: auto; }
    .pista form { width: 100%; }
    .linha-resultado { grid-template-columns: 32px 1fr auto; }
  }
</style>
</head>
<body>
<div class="faixa"></div>
<div class="topo">
  <p class="rotulo-evento">Circuito Social COMPAZ · robótica ao vivo</p>
  <h1>Corrida Multi EV3</h1>
  <p class="subtitulo">Passa no marcador de cada pista pra largar o robô, passa de novo quando ele chegar. O tempo fica registrado na hora.</p>
</div>

<div class="envolto">
  <section>
    <div class="titulo-secao"><h2>Pistas ao vivo</h2></div>
    <div id="pistas"></div>
  </section>

  <section>
    <div class="titulo-secao">
      <h2>Corrida atual</h2>
      <span class="contagem" id="contagemAtual">0 tempos</span>
    </div>
    <div class="placar" id="placarAtual"></div>
    <div class="vazio" id="vazioAtual">Nenhum resultado nessa corrida ainda.</div>
    <div class="rodape-secao">
      <button class="secundario" id="btnNovaCorrida">começar nova corrida</button>
    </div>
  </section>

  <section>
    <div class="titulo-secao">
      <h2>Recorde geral</h2>
      <span class="contagem" id="contagemGeral">0 tempos</span>
    </div>
    <div class="placar" id="placarGeral"></div>
    <div class="vazio" id="vazioGeral">Nenhum tempo registrado ainda.</div>
    <div class="rodape-secao">
      <button class="secundario" id="btnLimparGeral">limpar recorde geral</button>
    </div>
  </section>
</div>

<script>
let robosConhecidos = new Set();
let ultimoIdVisto = {};
let corridaAtual = [];
let recordeGeral = JSON.parse(localStorage.getItem('recorde_geral_ev3') || '[]');

const pistasEl = document.getElementById('pistas');
const placarAtualEl = document.getElementById('placarAtual');
const vazioAtualEl = document.getElementById('vazioAtual');
const contagemAtualEl = document.getElementById('contagemAtual');
const placarGeralEl = document.getElementById('placarGeral');
const vazioGeralEl = document.getElementById('vazioGeral');
const contagemGeralEl = document.getElementById('contagemGeral');

function corDoRobo(nome) {
  if (nome.includes('vermelho')) return 'vermelho';
  if (nome.includes('verde')) return 'verde';
  if (nome.includes('amarelo')) return 'amarelo';
  return '';
}

function bolinhaCor(nome) {
  const cor = corDoRobo(nome);
  return cor ? '<span class="ponto-cor cor-' + cor + '"></span>' : '';
}

function formatarTempo(s) {
  const min = Math.floor(s / 60);
  const seg = s - min * 60;
  return String(min).padStart(2, '0') + ':' + seg.toFixed(2).padStart(5, '0');
}

function adicionarPista(nome) {
  const div = document.createElement('div');
  div.className = 'pista';
  div.innerHTML =
    '<div class="robo-nome">' + bolinhaCor(nome) + nome + '</div>' +
    '<div class="numero" id="numero_' + nome + '">00:00.00</div>' +
    '<div class="rotulo" id="rotulo_' + nome + '">aguardando</div>' +
    '<form id="form_' + nome + '">' +
    '<input type="text" id="campoNome_' + nome + '" placeholder="Nome de quem correu">' +
    '<button type="submit">Registrar</button>' +
    '</form>';
  pistasEl.appendChild(div);
  ultimoIdVisto[nome] = -1;
  robosConhecidos.add(nome);

  document.getElementById('form_' + nome).addEventListener('submit', (ev) => {
    ev.preventDefault();
    const campo = document.getElementById('campoNome_' + nome);
    const nomeCompetidor = campo.value.trim();
    const tempoGuardado = div.dataset.tempoPendente;
    if (!nomeCompetidor || !tempoGuardado) return;
    registrarResultado(nome, nomeCompetidor, parseFloat(tempoGuardado));
    campo.value = '';
    div.dataset.tempoPendente = '';
  });
}

function registrarResultado(robo, nomeCompetidor, tempo) {
  const registro = { id: Date.now() + '-' + Math.random(), robo, nome: nomeCompetidor, tempo };
  corridaAtual.push(registro);
  recordeGeral.push(registro);
  localStorage.setItem('recorde_geral_ev3', JSON.stringify(recordeGeral));
  renderizarPlacar(corridaAtual, placarAtualEl, vazioAtualEl, contagemAtualEl);
  renderizarPlacar(recordeGeral, placarGeralEl, vazioGeralEl, contagemGeralEl);
}

function renderizarPlacar(lista, placarEl, vazioEl, contagemEl) {
  const ordenado = [...lista].sort((a, b) => a.tempo - b.tempo);
  placarEl.innerHTML = '';
  vazioEl.style.display = ordenado.length ? 'none' : 'block';
  contagemEl.textContent = ordenado.length + (ordenado.length === 1 ? ' tempo' : ' tempos');
  ordenado.forEach((reg, i) => {
    const linha = document.createElement('div');
    linha.className = 'linha-resultado' + (i === 0 ? ' primeiro' : '');
    linha.innerHTML =
      '<div class="posicao">' + (i + 1) + '</div>' +
      '<div class="quem"><span class="robo">' + bolinhaCor(reg.robo) + reg.robo + '</span>' + reg.nome + '</div>' +
      '<div class="tempo">' + formatarTempo(reg.tempo) + '</div>';
    placarEl.appendChild(linha);
  });
}

document.getElementById('btnNovaCorrida').addEventListener('click', () => {
  corridaAtual = [];
  renderizarPlacar(corridaAtual, placarAtualEl, vazioAtualEl, contagemAtualEl);
});

document.getElementById('btnLimparGeral').addEventListener('click', () => {
  if (recordeGeral.length && confirm('Limpar o recorde geral?')) {
    recordeGeral = [];
    localStorage.setItem('recorde_geral_ev3', JSON.stringify(recordeGeral));
    renderizarPlacar(recordeGeral, placarGeralEl, vazioGeralEl, contagemGeralEl);
  }
});

async function atualizar() {
  try {
    const r = await fetch('/estado');
    const dados = await r.json();

    for (const nome of Object.keys(dados)) {
      if (!robosConhecidos.has(nome)) {
        adicionarPista(nome);
      }
      const d = dados[nome];
      const numeroEl = document.getElementById('numero_' + nome);
      const rotuloEl = document.getElementById('rotulo_' + nome);
      const pistaEl = document.getElementById('form_' + nome).closest('.pista');

      if (d.rodando) {
        numeroEl.textContent = formatarTempo(d.tempo);
        rotuloEl.textContent = 'correndo';
        rotuloEl.className = 'rotulo correndo';
      } else if (d.id_finalizacao > ultimoIdVisto[nome] && d.ultimo_tempo !== null) {
        numeroEl.textContent = formatarTempo(d.ultimo_tempo);
        rotuloEl.textContent = 'chegou';
        rotuloEl.className = 'rotulo chegou';
        pistaEl.dataset.tempoPendente = d.ultimo_tempo.toFixed(2);
        if (ultimoIdVisto[nome] >= 0) document.getElementById('campoNome_' + nome).focus();
        ultimoIdVisto[nome] = d.id_finalizacao;
      }
    }
  } catch (e) { /* servidor ainda subindo */ }
}
setInterval(atualizar, 150);

renderizarPlacar(corridaAtual, placarAtualEl, vazioAtualEl, contagemAtualEl);
renderizarPlacar(recordeGeral, placarGeralEl, vazioGeralEl, contagemGeralEl);
</script>
</body>
</html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path == '/' or self.path.startswith('/index'):
            corpo = PAGINA_HTML.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(corpo)))
            self.end_headers()
            self.wfile.write(corpo)
        elif self.path == '/estado':
            corpo = estado_completo_json().encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(corpo)))
            self.end_headers()
            self.wfile.write(corpo)
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        # /estado/robo2  ou  /estado/robo3 — recebe o estado já pronto
        # mandado pelos outros terminais e guarda pra servir no GET /estado
        if self.path.startswith('/estado/'):
            nome = self.path.split('/estado/', 1)[1]
            tamanho = int(self.headers.get('Content-Length', 0))
            corpo = self.rfile.read(tamanho)
            try:
                dados = json.loads(corpo)
                with lock_estado:
                    estados_externos[nome] = dados
                self.send_response(204)
                self.end_headers()
            except Exception:
                self.send_response(400)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()


def iniciar_servidor():
    servidor = ThreadingHTTPServer(('0.0.0.0', PORTA_SERVIDOR), Handler)
    threading.Thread(target=servidor.serve_forever, daemon=True).start()


# ===================================================================
if __name__ == "__main__":
    pygame.init()
    pygame.joystick.init()

    iniciar_servidor()
    url = f'http://127.0.0.1:{PORTA_SERVIDOR}/'
    print(f"Página aberta em {url}")
    print("Os outros 2 terminais mandam o estado deles pra cá — deixa esse de pé.")
    webbrowser.open(url)

    # Vários controles saem com o mesmo nome (Remote Gamepad e até
    # físicos tipo Nova Lite aparecem todos como "Xbox 360 Controller"),
    # então índice/nome não servem pra identificar qual é qual.
    # Em vez disso: conecta quantos controles quiser, e aperta UM
    # botão no controle que é desse robô pra confirmar.
    print(f"Conecta o controle do {NOME_ROBO} e aperta um botão nele pra confirmar.")

    parar = threading.Event()
    candidatos = {}  # instance_id -> objeto Joystick
    joystick = None

    while not parar.is_set() and joystick is None:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                parar.set()
            elif evento.type == pygame.KEYDOWN and evento.key == pygame.K_ESCAPE:
                parar.set()
            elif evento.type == pygame.JOYDEVICEADDED:
                j = pygame.joystick.Joystick(evento.device_index)
                j.init()
                candidatos[j.get_instance_id()] = j
                print(f"Detectado: {j.get_name()} (id {j.get_instance_id()}) — aperta um botão nele se for o do {NOME_ROBO}.")
            elif evento.type == pygame.JOYBUTTONDOWN and evento.instance_id in candidatos:
                joystick = candidatos[evento.instance_id]
                print(f"Confirmado -> {NOME_ROBO} vai usar: {joystick.get_name()} (id {joystick.get_instance_id()})")
            elif evento.type == pygame.JOYDEVICEREMOVED:
                candidatos.pop(evento.instance_id, None)
        time.sleep(0.05)

    if joystick is not None:
        try:
            with RoboEV3(MAC_ROBO) as robo:
                mover = robo.mover_continuo
                ler = robo.ler_sensor
                modo_gatilho = p.MODO_COR_COR

                piscar_identidade(robo, vezes=3, atraso=0.2)
                robo.apitar()
                print(f"✅ {NOME_ROBO} ({MAC_ROBO}) conectado.")

                mapa = escolher_mapeamento(joystick.get_name())
                eixo_rt, eixo_lt, eixo_direcao = mapa['rt'], mapa['lt'], mapa['direcao']

                pygame.event.pump()
                time.sleep(0.1)
                pygame.event.pump()
                repouso_rt = joystick.get_axis(eixo_rt)
                repouso_lt = joystick.get_axis(eixo_lt)

                acelerador = 0.0
                esq_atual = dir_atual = 0
                esq_enviado = dir_enviado = None
                sobre_marcador = False

                while not parar.is_set():
                    for evento in pygame.event.get():
                        if evento.type == pygame.QUIT:
                            parar.set()
                        elif evento.type == pygame.KEYDOWN and evento.key == pygame.K_ESCAPE:
                            parar.set()

                    cor_lida = ler(PORTA_GATILHO, modo_gatilho)
                    no_marcador = (cor_lida == CODIGO_COR_GATILHO)

                    if no_marcador and not sobre_marcador:
                        sobre_marcador = True
                        if not esta_rodando_robo1():
                            largar_robo1()
                            robo.apitar(frequencia=880, duracao_ms=100)
                            piscar_identidade(robo, vezes=1)
                        else:
                            tempo = chegar_robo1()
                            robo.apitar(frequencia=440, duracao_ms=200)
                            piscar_identidade(robo, vezes=2)
                            print(f"{NOME_ROBO} CHEGOU: {tempo:.2f}s")
                    elif not no_marcador:
                        sobre_marcador = False

                    rt = gatilho_para_0_1(joystick.get_axis(eixo_rt), repouso_rt)
                    lt = gatilho_para_0_1(joystick.get_axis(eixo_lt), repouso_lt)
                    stick_x = aplicar_zona_morta(
                        joystick.get_axis(eixo_direcao), ZONA_MORTA_STICK
                    )

                    if rt > 0 and lt == 0:
                        acelerador += ACELERACAO_POR_S * rt * TAXA_LOOP_S
                    elif lt > 0 and rt == 0:
                        acelerador -= ACELERACAO_POR_S * lt * TAXA_LOOP_S
                    else:
                        if acelerador > 0:
                            acelerador = max(0.0, acelerador - FREADA_POR_S * TAXA_LOOP_S)
                        elif acelerador < 0:
                            acelerador = min(0.0, acelerador + FREADA_POR_S * TAXA_LOOP_S)

                    acelerador = limitar(acelerador, -VEL_MAX, VEL_MAX)

                    esq_alvo = limitar(acelerador + stick_x * GANHO_VIRA, -100, 100)
                    dir_alvo = limitar(acelerador - stick_x * GANHO_VIRA, -100, 100)

                    esq_atual = aproximar(esq_atual, esq_alvo, RAMPA_MOTOR)
                    dir_atual = aproximar(dir_atual, dir_alvo, RAMPA_MOTOR)

                    esq = int(esq_atual)
                    dir_ = int(dir_atual)

                    if esq != esq_enviado:
                        mover(MOTOR_ESQ, esq * SINAL_ESQ)
                        esq_enviado = esq
                    if dir_ != dir_enviado:
                        mover(MOTOR_DIR, dir_ * SINAL_DIR)
                        dir_enviado = dir_

                    time.sleep(TAXA_LOOP_S)

                robo.parar_motor(MOTOR_ESQ)
                robo.parar_motor(MOTOR_DIR)
                robo.led('DESLIGADO')
                print(f"{NOME_ROBO} parado.")

        except Exception as e:
            print(f"❌ {NOME_ROBO} ({MAC_ROBO}) caiu: {e}")

    pygame.quit()
    print("Servidor e robô 1 encerrados.")
