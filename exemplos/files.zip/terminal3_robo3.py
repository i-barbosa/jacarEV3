"""
TERMINAL 3 — roda DEPOIS do terminal 1 (terminal1_robo1_servidor.py).
Precisa de: pip install pygame

Controla só o robô 3 e manda o estado dele pro servidor (porta 8765,
que tá rodando no terminal 1) via HTTP. Não abre página nenhuma
aqui — a página é a do terminal 1.

Antes de rodar: conecta SÓ o controle do robô 3. Se já tiver mais de
um controle conectado, passa o índice dele:
  python terminal3_robo3.py 0

Se o endereço do servidor for outro PC (não 127.0.0.1), muda
ENDERECO_SERVIDOR lá embaixo.

ESC ou fecha a janela do pygame = para o robô 3.
"""
import json
import os
import sys
import time
import urllib.request

os.environ['SDL_JOYSTICK_HIDAPI'] = '0'

import pygame
from jacarev3 import RoboEV3, protocolo as p

NOME_ROBO = 'robo3-amarelo'
MAC_ROBO = '00:16:53:65:0b:38'
COR_IDENTIDADE = 'AMARELO'  # cor fixa do LED enquanto esse robô roda
ENDERECO_SERVIDOR = 'http://127.0.0.1:8765'

MOTOR_ESQ = 'C'
MOTOR_DIR = 'B'
SINAL_ESQ = -1
SINAL_DIR = -1

PORTA_GATILHO = 4
CODIGO_COR_GATILHO = 5  # 5 = vermelho

EIXO_RT = 4
EIXO_LT = 5
EIXO_DIRECAO = 0

# Mapeamento por marca de controle — ver explicação no terminal1.
MAPEAMENTOS_CONHECIDOS = [
    (['xbox', '360', 'xinput'], {'rt': EIXO_RT, 'lt': EIXO_LT, 'direcao': EIXO_DIRECAO}),
    (['wireless controller', 'ps4', 'dualshock', 'sony'], {'rt': 4, 'lt': 3, 'direcao': 0}),  # <- confirmar
]
MAPEAMENTO_PADRAO = {'rt': EIXO_RT, 'lt': EIXO_LT, 'direcao': EIXO_DIRECAO}


def escolher_mapeamento(nome_controle):
    nome = nome_controle.lower()
    for chaves, mapa in MAPEAMENTOS_CONHECIDOS:
        if any(chave in nome for chave in chaves):
            return mapa
    print(f"Controle '{nome_controle}' não tá na lista de mapeamentos — usando padrão Xbox.")
    return MAPEAMENTO_PADRAO

VEL_MAX = 60
GANHO_VIRA = 35
ACELERACAO_POR_S = 50
FREADA_POR_S = 90
RAMPA_MOTOR = 14

ZONA_MORTA_STICK = 0.15
ZONA_MORTA_GATILHO = 0.05
TAXA_LOOP_S = 0.05


def limitar(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def aproximar(atual, alvo, passo_max):
    diff = alvo - atual
    if diff > passo_max:
        diff = passo_max
    elif diff < -passo_max:
        diff = -passo_max
    return atual + diff


def aplicar_zona_morta(v, zona):
    if -zona < v < zona:
        return 0.0
    sinal = -1.0 if v < 0 else 1.0
    return sinal * (abs(v) - zona) / (1 - zona)


def gatilho_para_0_1(valor_eixo, repouso):
    escala = 1 - repouso
    if escala <= 0:
        return 0.0
    v = (valor_eixo - repouso) / escala
    v = max(0.0, v)
    return v if v > ZONA_MORTA_GATILHO else 0.0


def ligar_led_identidade(robo):
    # LED fica sempre na cor do robô — largada/chegada avisam por
    # apito (frequência já diferente pra cada um), não trocando a
    # cor, senão perde a identidade visual no meio da corrida.
    try:
        robo.led(COR_IDENTIDADE)
    except Exception as e:
        print(f"Aviso: cor de LED '{COR_IDENTIDADE}' não existe nesse firmware ({e}) — usando verde.")
        robo.led('VERDE')


def piscar_identidade(robo, vezes=1, atraso=0.15):
    for _ in range(vezes):
        robo.led('DESLIGADO')
        time.sleep(atraso)
        ligar_led_identidade(robo)
        time.sleep(atraso)


def enviar_estado(dados):
    # Não derruba o robô se o servidor cair/demorar — só ignora.
    try:
        corpo = json.dumps(dados).encode('utf-8')
        req = urllib.request.Request(
            f'{ENDERECO_SERVIDOR}/estado/{NOME_ROBO}',
            data=corpo,
            headers={'Content-Type': 'application/json'},
            method='POST',
        )
        urllib.request.urlopen(req, timeout=0.3)
    except Exception:
        pass


if __name__ == "__main__":
    pygame.init()
    pygame.joystick.init()

    # Vários controles saem com o mesmo nome (Remote Gamepad e até
    # físicos tipo Nova Lite aparecem todos como "Xbox 360 Controller"),
    # então índice/nome não servem pra identificar qual é qual.
    # Em vez disso: conecta quantos controles quiser, e aperta UM
    # botão no controle que é desse robô pra confirmar.
    print(f"Conecta o controle do {NOME_ROBO} e aperta um botão nele pra confirmar.")
    print(f"Mandando estado pra {ENDERECO_SERVIDOR} — confere se o terminal 1 já tá de pé.")

    parar = False
    candidatos = {}  # instance_id -> objeto Joystick
    joystick = None

    while not parar and joystick is None:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                parar = True
            elif evento.type == pygame.KEYDOWN and evento.key == pygame.K_ESCAPE:
                parar = True
            elif evento.type == pygame.JOYDEVICEADDED:
                j = pygame.joystick.Joystick(evento.device_index)
                j.init()
                candidatos[j.get_instance_id()] = j
                print(f"Detectado: {j.get_name()} (id {j.get_instance_id()}) — aperta um botão nele se for o do {NOME_ROBO}.")
            elif evento.type == pygame.JOYBUTTONDOWN and evento.instance_id in candidatos:
                joystick = candidatos[evento.instance_id]
                print(f"Confirmado -> {NOME_ROBO} vai usar: {joystick.get_name()} (id {joystick.get_instance_id()})")
            elif evento.type == pygame.JOYDEVICEREMOVED:
                candidatos.pop(evento.instance_id, None)
        time.sleep(0.05)

    if joystick is not None:
        try:
            with RoboEV3(MAC_ROBO) as robo:
                mover = robo.mover_continuo
                ler = robo.ler_sensor
                modo_gatilho = p.MODO_COR_COR

                piscar_identidade(robo, vezes=3, atraso=0.2)
                robo.apitar()
                print(f"✅ {NOME_ROBO} ({MAC_ROBO}) conectado.")

                mapa = escolher_mapeamento(joystick.get_name())
                eixo_rt, eixo_lt, eixo_direcao = mapa['rt'], mapa['lt'], mapa['direcao']

                pygame.event.pump()
                time.sleep(0.1)
                pygame.event.pump()
                repouso_rt = joystick.get_axis(eixo_rt)
                repouso_lt = joystick.get_axis(eixo_lt)

                acelerador = 0.0
                esq_atual = dir_atual = 0
                esq_enviado = dir_enviado = None
                sobre_marcador = False

                rodando = False
                largada = None
                ultimo_tempo = None
                id_finalizacao = 0

                while not parar:
                    for evento in pygame.event.get():
                        if evento.type == pygame.QUIT:
                            parar = True
                        elif evento.type == pygame.KEYDOWN and evento.key == pygame.K_ESCAPE:
                            parar = True

                    cor_lida = ler(PORTA_GATILHO, modo_gatilho)
                    no_marcador = (cor_lida == CODIGO_COR_GATILHO)

                    if no_marcador and not sobre_marcador:
                        sobre_marcador = True
                        if not rodando:
                            rodando = True
                            largada = time.perf_counter()
                            robo.apitar(frequencia=880, duracao_ms=100)
                            piscar_identidade(robo, vezes=1)
                        else:
                            ultimo_tempo = time.perf_counter() - largada
                            rodando = False
                            id_finalizacao += 1
                            robo.apitar(frequencia=440, duracao_ms=200)
                            piscar_identidade(robo, vezes=2)
                            print(f"{NOME_ROBO} CHEGOU: {ultimo_tempo:.2f}s")
                    elif not no_marcador:
                        sobre_marcador = False

                    tempo_atual = (time.perf_counter() - largada) if (rodando and largada) else 0.0
                    enviar_estado({
                        'rodando': rodando,
                        'tempo': tempo_atual,
                        'ultimo_tempo': ultimo_tempo,
                        'id_finalizacao': id_finalizacao,
                    })

                    rt = gatilho_para_0_1(joystick.get_axis(eixo_rt), repouso_rt)
                    lt = gatilho_para_0_1(joystick.get_axis(eixo_lt), repouso_lt)
                    stick_x = aplicar_zona_morta(
                        joystick.get_axis(eixo_direcao), ZONA_MORTA_STICK
                    )

                    if rt > 0 and lt == 0:
                        acelerador += ACELERACAO_POR_S * rt * TAXA_LOOP_S
                    elif lt > 0 and rt == 0:
                        acelerador -= ACELERACAO_POR_S * lt * TAXA_LOOP_S
                    else:
                        if acelerador > 0:
                            acelerador = max(0.0, acelerador - FREADA_POR_S * TAXA_LOOP_S)
                        elif acelerador < 0:
                            acelerador = min(0.0, acelerador + FREADA_POR_S * TAXA_LOOP_S)

                    acelerador = limitar(acelerador, -VEL_MAX, VEL_MAX)

                    esq_alvo = limitar(acelerador + stick_x * GANHO_VIRA, -100, 100)
                    dir_alvo = limitar(acelerador - stick_x * GANHO_VIRA, -100, 100)

                    esq_atual = aproximar(esq_atual, esq_alvo, RAMPA_MOTOR)
                    dir_atual = aproximar(dir_atual, dir_alvo, RAMPA_MOTOR)

                    esq = int(esq_atual)
                    dir_ = int(dir_atual)

                    if esq != esq_enviado:
                        mover(MOTOR_ESQ, esq * SINAL_ESQ)
                        esq_enviado = esq
                    if dir_ != dir_enviado:
                        mover(MOTOR_DIR, dir_ * SINAL_DIR)
                        dir_enviado = dir_

                    time.sleep(TAXA_LOOP_S)

                robo.parar_motor(MOTOR_ESQ)
                robo.parar_motor(MOTOR_DIR)
                robo.led('DESLIGADO')
                print(f"{NOME_ROBO} parado.")

        except Exception as e:
            print(f"❌ {NOME_ROBO} ({MAC_ROBO}) caiu: {e}")

    pygame.quit()
    print(f"{NOME_ROBO} encerrado.")
